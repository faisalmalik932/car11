      <div class="col-md-3 col-sm-3">
        <div class="profile_nav">
          <ul>
            <li><a href="<?php echo base_url() ?>profile">Profile Settings</a></li>
            <!-- <li><a href="<?php //echo base_url() ?>vehicle/my_vehicles">My Vehicles</a></li>
            <li><a href="<?php //echo base_url() ?>vehicle/post_vehicles">Post a Vehicles</a></li> -->
            <li><a href="<?php echo base_url() ?>logout">Sign Out</a></li>
          </ul>
        </div>
      </div>

